﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour {

    private static UIManager instance = null;
    public static UIManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<UIManager>();
                if (instance == null)
                {
                    GameObject container = new GameObject("UIManager");
                    instance = container.AddComponent<UIManager>();
                }
            }
            return instance;
        }
    }

    // 임시 UI관련
    public Text stateUI;
    public Text winnerUI;
    public Text AIsayUI;
    public GameObject mainmenu;
    public GameObject endmenu;
    public int AIsayState = 0;
    // 캡슐화
    private int turnCount;
    public int TurnCount
    {
        get { return turnCount; }
        set { turnCount = value; }
    }

    private void Awake()
    {
        endmenu.SetActive(false);
    }

    public void UIupdate()
    {
        AIsayState=Random.Range(1, 10);

        switch (AIsayState)
        {
            case 1:
                AIsayUI.text = "꽤 하는놈이군 !";
                break;
            case 2:
                AIsayUI.text = "하핫 꽤 재밌는걸 !";
                break;
            case 3:
                AIsayUI.text = "Minsu is best programmer.";
                break;
            case 4:
                AIsayUI.text = "넌 날 이길수엄찌 !";
                break;
            case 5:
                AIsayUI.text = "죽어라 !";
                break;
            case 6:
                AIsayUI.text = "호에에엥";
                break;
            case 7:
                AIsayUI.text = "할말이 없다능";
                break;
            case 8:
                AIsayUI.text = "받아랏 !";
                break;
            case 9:
                AIsayUI.text = "음핫핫핫 !";
                break;
            default:
                break;
        }

        stateUI.text = "TURN : " + TurnCount;
        if (!GameManager.Instance.isPlaying)
        {
            endmenu.SetActive(true);
        }
    }

    public void PlayerFirst()
    {
        GameManager.Instance.currentTurn = Turn.PLAYER_TURN;
        GameManager.Instance.isPlaying = true;
        GameManager.Instance.currentStone = Stone.BLACK_STONE;
        GameManager.Instance.oppsiteStone = Stone.BLACK_STONE;
        mainmenu.SetActive(false);
    }

    public void AIFirst()
    {
        GameManager.Instance.currentTurn = Turn.AI_TURN;
        GameManager.Instance.isPlaying = true;
        GameManager.Instance.currentStone = Stone.BLACK_STONE;
        GameManager.Instance.oppsiteStone = Stone.WHITE_STONE;
        mainmenu.SetActive(false);
    }

    public void ReStart()
    {
        SceneManager.LoadScene("Game");
    }

}
