﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 배열 기본값이 0이라 NONE을 이용함.
public enum Stone { NONE, BLACK_STONE, WHITE_STONE }
public enum Turn { PLAYER_TURN, AI_TURN }

public class GameManager : MonoBehaviour {

    #region # field #
    // 싱글톤
    private static GameManager instance = null;
    public static GameManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<GameManager>();
                // 그래도 없다면
                if(instance==null)
                {
                    GameObject container = new GameObject("GameManager");
                    instance = container.AddComponent<GameManager>();
                }
            }
            return instance;
        }
    }
    // UImanager에서 시작값 설정...
    public Stone currentStone;
    public Stone oppsiteStone;
    public Turn currentTurn;

    // 오목데이터 저장용 2차원 배열
    private static byte SIZE = 15;
    public int[,] BoardData = new int[SIZE, SIZE];

    [Header("Prefabs")]
    //프리팹들 ( 흑돌, 백돌, 턴표시 )
    public GameObject BlackStone;
    public GameObject WhiteStone;
    public GameObject turnTextObj;
    // 프리팹 홀더
    public GameObject StoneHolder;
    public GameObject turnNumHolder;

    // 게임 플레이, 종료 체크
    public bool isPlaying = false;

    #endregion

    private void Awake()
    {
        isPlaying = false;
    }

    // 위치를 받아, 스톤 인스턴스를 생성
    public void PutStone(GameObject obj)
    {
        // 행, 열
        int column = 0, row = 0;

        // obj의 이름과 부모이름을 이용해서 좌표값을 저장한다.
        string objName = obj.name;
        string objParentName = obj.transform.parent.name;

        // y(col),x(row)
        column = System.Convert.ToInt32(objParentName);
        row = System.Convert.ToInt32(objName);

        // turnUI 묻혀서 위치를 아예 새로만듬.
        Vector3 turnPos = new Vector3(obj.transform.position.x, obj.transform.position.y, -1);

        // BoardData와 위치가 중첩되지 않을때, 즉 0일때
        if (BoardData[column, row] == (int)(Stone.NONE))
        {
            // 위치 기록
            BoardData[column, row] = (int)(currentStone);

            switch (currentStone)
            {
                case Stone.BLACK_STONE:
                    Instantiate(BlackStone, obj.transform.position, Quaternion.identity, StoneHolder.transform);
                    Instantiate(turnTextObj, turnPos, Quaternion.identity, turnNumHolder.transform);

                    if (IsFive(currentStone)) // 승리시
                    {
                        UIManager.Instance.winnerUI.text = "Winner : " + currentTurn.ToString();
                        isPlaying = false;
                    }
                    currentStone = Stone.WHITE_STONE;
                    break;

                case Stone.WHITE_STONE:
                    Instantiate(WhiteStone, obj.transform.position, Quaternion.identity, StoneHolder.transform);
                    Instantiate(turnTextObj, turnPos, Quaternion.identity, turnNumHolder.transform);

                    if (IsFive(currentStone))
                    {
                        UIManager.Instance.winnerUI.text = "Winner : " + currentTurn.ToString();
                        isPlaying = false;
                    }
                    currentStone = Stone.BLACK_STONE;
                    break;
            }

            switch (currentTurn)
            {
                case Turn.PLAYER_TURN:
                    Debug.Log("Player: " + column + "행, " + row+"열");
                    currentTurn = Turn.AI_TURN;
                    break;

                case Turn.AI_TURN:
                    currentTurn = Turn.PLAYER_TURN;
                    UIManager.Instance.TurnCount++;
                    break;
            }

            // UI 업데이트
            UIManager.Instance.UIupdate();
        }
        else
        {
            Debug.Log("중복된 위치 입니다...!");
        }
    }

    bool IsFive(Stone stone)
    {
        // 행승리 체크
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 10; row++)
            {
                bool match = true;
                for (int i = 0; i < 5; i++)
                {
                    if ( (int)stone != BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match) return true;
            }
        }
        // 열승리 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 10; col++)
            {
                bool match = true;
                for (int i = 0; i < 5; i++)
                {
                    if ( (int)stone != BoardData[col + i, row] )
                    {
                        match = false;
                    }
                }
                if (match) return true;
            }

        }
        // 대각선 왼쪽승리 체크 (나란히 감소하거나 증가하거나)
        for(int col=0; col<=10; col++)
        {
            for(int row=0; row<=10; row++)
            {
                bool match = true;
                for (int i = 0; i < 5; i++)
                {
                    if ((int)stone != BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match) return true;
            }
        }
        // 대각선 오른쪽승리 체크 (행증가 열감소)
        for (int col = 0; col <= 10; col++)
        {
            for (int row = 0; row <= 10; row++)
            {
                bool match = true;
                for (int i = 0; i < 5; i++)
                {
                    if ((int)stone != BoardData[col + i, row + 4 - i])
                    {
                        match = false;
                    }
                }
                if (match) return true;
            }
        }

        return false;
    }
}
