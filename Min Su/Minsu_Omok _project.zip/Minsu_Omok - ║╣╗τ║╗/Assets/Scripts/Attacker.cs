﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attacker : MonoBehaviour
{
    private GameObject AInewStonePos = null;
    private GameObject board;

    private bool turnIsDone=false;
    private static int SIZE = 15;

    #region #it is Fixed_Methhod
    private void Awake()
    {
        board = GameObject.Find("Board");
    }

    private void Update()
    {
        if (GameManager.Instance.isPlaying)
        {
            if (GameManager.Instance.currentTurn == Turn.AI_TURN)
            {
                AIPutStone();
            }
        }
    }

    //int로 받은 인수를 게임 오브젝트로 사상(mapping).
    private void GetStonePos(int y, int x)
    {
        Transform[] boardChild1 = new Transform[board.transform.childCount];

        for (int i = 0; i < board.transform.childCount; i++)
            boardChild1[i] = board.transform.GetChild(i);

        Transform[] boardChild2 = new Transform[boardChild1[y].childCount];

        for (int i = 0; i < boardChild1[y].childCount; i++)
            boardChild2[i] = boardChild1[y].transform.GetChild(i);

        AInewStonePos = boardChild2[x].gameObject;
    }
    #endregion

    private void AIPutStone()
    {
        //턴이 시작될때 초기화
        //curretStone : 자신의 차례의 돌 체크 즉 AI입장에서 공격, oppsiteStone : 상대방 돌 체크 즉 플레이어의 공격수를 방어.
        turnIsDone = false;

        // 자신의 열린 4, 막힌4에 공격, 상대방의 막힌 4에 방어.
        if (!turnIsDone) turnIsDone = IsOpenFour(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = IsCloseFour(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = IsCloseFour(GameManager.Instance.oppsiteStone);

        // 자신의 열린 1011 공격, 상대방의 열린 1011 방어
        if (!turnIsDone) turnIsDone = IsOpenTwoOneSpace(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = IsOpenTwoOneSpace(GameManager.Instance.oppsiteStone);

        // 자신의 열린3, 막힌3에 공격, 상대방의 열린 3에, 막힌 3에 방어.
        if (!turnIsDone) turnIsDone = IsOpenThree(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = IsCloseThree(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = IsOpenThree(GameManager.Instance.oppsiteStone);
        if (!turnIsDone) turnIsDone = IsCloseThree(GameManager.Instance.oppsiteStone);

        // 자신의 열린2, 막힌2에 공격
        if (!turnIsDone) turnIsDone = IsOpenTwo(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = IsCloseTwo(GameManager.Instance.currentStone);

        // 아무곳이나 연결.
        if (!turnIsDone) turnIsDone = IsOne(GameManager.Instance.currentStone);
        if (!turnIsDone) turnIsDone = PutSometing();

        // 상대방의 열린2, 막힌2 방어
        if (!turnIsDone) turnIsDone = IsOpenTwo(GameManager.Instance.oppsiteStone);
        if (!turnIsDone) turnIsDone = IsCloseTwo(GameManager.Instance.oppsiteStone);
    }

    bool IsOpenTwoOneSpace(Stone stone)
    {
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;

                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // 행 1-1-0-1 오른쪽 체크
                    if ((row + 3) < SIZE && GameManager.Instance.BoardData[col, row + 3] == (int)(stone)
                        && GameManager.Instance.BoardData[col, row+2]==(int)Stone.NONE)
                    {
                        GetStonePos(col, row + 2);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 행 1-0-1-1 왼쪽 체크
                    if ((row -2) >=0 && GameManager.Instance.BoardData[col, row-2] == (int)(stone)
                         && GameManager.Instance.BoardData[col, row -1] == (int)Stone.NONE)
                    {
                        GetStonePos(col, row -1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row -1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        // 열린 열 2개 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 13; col++)
            {
                bool match = true;

                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // 열 아래로 체크
                    if ((col + 3) < SIZE && GameManager.Instance.BoardData[col+3, row] == (int)(stone)
                        && GameManager.Instance.BoardData[col+2, row] == (int)Stone.NONE)
                    {
                        GetStonePos(col+2, row);
                        Debug.Log("* AI put: " + (col+2) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 열 위로 체크
                    if ((col - 2) >= 0 && GameManager.Instance.BoardData[col-2, row] == (int)(stone)
                         && GameManager.Instance.BoardData[col-1, row] == (int)Stone.NONE)
                    {
                        GetStonePos(col-1, row);
                        Debug.Log("* AI put: " + (col-1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }

        }
        // 대각선 왼쪽 체크
        for (int col = 0; col <= 13; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;
                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ((col - 2) >= 0 && (row - 2) >= 0 && GameManager.Instance.BoardData[col - 2, row - 2] == (int)(stone)
                        && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col -1, row-1);
                        Debug.Log("* AI put: " + (col -1) + "행, " + (row -1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 3) < SIZE && (row + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row + 3] == (int)(stone)
                        && GameManager.Instance.BoardData[col + 2, row + 2] == (int)(Stone.NONE))
                    {
                        GetStonePos(col +2 , row +2 );
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }
        // 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 13; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;
                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 1 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 2) >= 0 && (row + 3) < SIZE && GameManager.Instance.BoardData[col - 2, row + 3] == (int)(stone)
                        && (col - 1) >= 0 && (row + 2) < SIZE && GameManager.Instance.BoardData[col - 1, row + 2] == (int)(Stone.NONE) )
                    {
                        GetStonePos(col - 1, row + 2);
                        Debug.Log("* AI put: " + (col - 2) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 3) < SIZE && (row - 2) >= 0 && GameManager.Instance.BoardData[col + 3, row - 2] == (int)(stone)
                        && (col + 2) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 2, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 2, row - 1);
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        return false;
    }

    #region #Method that it check route opened stone

    bool IsOpenFour(Stone stone)
    {
        // 현재는 랜덤, open일때 두가지 방향 중 하나를 상황에 따라 선택하기 위함...
        int calculateState = Random.Range(1, 3);

        // 열린 행 체크 (0, 0) (0, 1) (0, 2)
        // x-1, x+2
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 11; row++)
            {
                bool match = true;

                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE)
                        && (row + 4) < SIZE && GameManager.Instance.BoardData[col, row + 4] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col, row - 1);
                                Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col, row + 4);
                                Debug.Log("* AI put: " + (col) + "행, " + (row + 4) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                        }
                    }
                }
            }
        }

        // 열린 열 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 11; col++)
            {
                bool match = true;

                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE)
                        && (col + 4) < SIZE && GameManager.Instance.BoardData[col + 4, row] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col - 1, row);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col + 4, row);
                                Debug.Log("* AI put: " + (col + 4) + "행, " + (row) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }

        }
        // 대각선 왼쪽 체크 (나란히 감소하거나 증가하거나)
        for (int col = 0; col <= 11; col++)
        {
            for (int row = 0; row <= 11; row++)
            {
                bool match = true;
                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ((col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE)
                        && (col + 4) < SIZE && (row + 4) < SIZE && GameManager.Instance.BoardData[col + 4, row + 4] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col - 1, row - 1);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col + 4, row + 4);
                                Debug.Log("* AI put: " + (col + 4) + "행, " + (row + 4) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }
        }
        // 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 11; col++)
        {
            for (int row = 0; row <= 11; row++)
            {
                bool match = true;
                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 3 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && (row + 4) < SIZE && GameManager.Instance.BoardData[col - 1, row + 4] == (int)(Stone.NONE)
                        && (col + 4) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 4, row - 1] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col - 1, row + 4);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 4) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                UIManager.Instance.AIsayUI.text = "하하하 나의 승리다 !";
                                GetStonePos(col + 4, row - 1);
                                Debug.Log("* AI put: " + (col + 4) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }
        }

        return false;
    }

    bool IsOpenThree(Stone stone)
    {
        // 현재는 랜덤, open일때 두가지 방향 중 하나를 상황에 따라 선택하기 위함...
        int calculateState = Random.Range(1, 3);

        // 열린 행 체크 (0, 0) (0, 1) (0, 2)
        // x-1, x+2
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 12; row++)
            {
                bool match = true;

                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE)
                        && (row + 3) < SIZE && GameManager.Instance.BoardData[col, row + 3] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col, row - 1);
                                Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col, row + 3);
                                Debug.Log("* AI put: " + (col) + "행, " + (row + 3) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                        }
                    }
                }
            }
        }

        // 열린 열 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 12; col++)
            {
                bool match = true;

                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE)
                        && (col + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 3, row);
                                Debug.Log("* AI put: " + (col + 3) + "행, " + (row) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }

        }
        // 대각선 왼쪽 체크 (나란히 감소하거나 증가하거나)
        for (int col = 0; col <= 12; col++)
        {
            for (int row = 0; row <= 12; row++)
            {
                bool match = true;
                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ((col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE)
                        && (col + 3) < SIZE && (row + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row + 3] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row - 1);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 3, row + 3);
                                Debug.Log("* AI put: " + (col + 3) + "행, " + (row + 3) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }
        }
        // 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 12; col++)
        {
            for (int row = 0; row <= 12; row++)
            {
                bool match = true;
                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 2 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && (row + 3) < SIZE && GameManager.Instance.BoardData[col - 1, row + 3] == (int)(Stone.NONE)
                        && (col + 3) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 3, row - 1] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row + 3);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 3) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 3, row - 1);
                                Debug.Log("* AI put: " + (col + 3) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }
        }

        return false;
    }

    bool IsOpenTwo(Stone stone)
    {
        // 현재는 랜덤, open일때 두가지 방향 중 하나를 상황에 따라 선택하기 위함...
        int calculateState= Random.Range(1, 3);

        // 열린 행 2개 체크 (0, 0) (0, 1) (0, 2)
        // x-1, x+2
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;

                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ( (row-1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE)
                        && (row + 2) < SIZE && GameManager.Instance.BoardData[col, row + 2] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col, row - 1);
                                Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col, row + 2);
                                Debug.Log("* AI put: " + (col) + "행, " + (row + 2) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                        }
                    }
                }
            }
        }
        
        // 열린 열 2개 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 13; col++)
            {
                bool match = true;

                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && GameManager.Instance.BoardData[col-1, row] == (int)(Stone.NONE)
                        && (col + 2) < SIZE && GameManager.Instance.BoardData[col + 2, row] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 2, row);
                                Debug.Log("* AI put: " + (col + 2) + "행, " + (row) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }

        }
        // 대각선 왼쪽 체크 (나란히 감소하거나 증가하거나)
        for (int col = 0; col <= 13; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;
                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ( (col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE)
                        && (col + 2) < SIZE && (row + 2) < SIZE && GameManager.Instance.BoardData[col + 2, row + 2] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row - 1);
                                Debug.Log("* AI put: " + (col - 2) + "행, " + (row - 2) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 2, row + 2);
                                Debug.Log("* AI put: " + (col + 2) + "행, " + (row + 2) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }
        }
        // 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 13; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;
                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 1 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && (row + 2) < SIZE && GameManager.Instance.BoardData[col - 1, row + 2] == (int)(Stone.NONE)
                        && (col + 2) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 2, row - 1] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row + 2);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 2) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 2, row - 1);
                                Debug.Log("* AI put: " + (col + 2) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }
                }
            }
        }
        
        return false;
    }

    #endregion.

    #region #Method that it check route closed stone.

    bool IsCloseFour(Stone stone)
    {
        Stone oppositeStone = stone;

        switch (stone)
        {
            case Stone.BLACK_STONE:
                oppositeStone = Stone.WHITE_STONE;
                break;
            case Stone.WHITE_STONE:
                oppositeStone = Stone.BLACK_STONE;
                break;
        }

        // 닫힌 행 4개 체크 (0, 0) (0, 1) (0, 2)
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 11; row++)
            {
                bool match = true;

                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(oppositeStone)
                        && (row + 4) < SIZE && GameManager.Instance.BoardData[col, row + 4] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 4);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 4) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((row + 4) < SIZE && GameManager.Instance.BoardData[col, row + 4] == (int)(oppositeStone)
                        && (row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((row) == 0 && GameManager.Instance.BoardData[col, row + 4] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 4);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 4) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((row + 4) == SIZE && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        // 닫힌 열 4개 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 11; col++)
            {
                bool match = true;

                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col + 4) < SIZE && GameManager.Instance.BoardData[col + 4, row] == (int)(oppositeStone)
                        && (col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(oppositeStone)
                        && (col + 4) < SIZE && GameManager.Instance.BoardData[col + 4, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 4, row);
                        Debug.Log("* AI put: " + (col + 4) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && GameManager.Instance.BoardData[col + 4, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 4, row);
                        Debug.Log("* AI put: " + (col + 4) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 4) == SIZE && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }

        }
        // 닫힌 대각선 왼쪽 체크 (나란히 감소하거나 증가하거나)
        for (int col = 0; col <= 11; col++)
        {
            for (int row = 0; row <= 11; row++)
            {
                bool match = true;
                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ((col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(oppositeStone)
                        && (col + 4) < SIZE && (row + 4) < SIZE && GameManager.Instance.BoardData[col + 4, row + 4] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 4, row + 4);
                        Debug.Log("* AI put: " + (col + 4) + "행, " + (row + 4) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;

                    }
                    if ((col + 4) < SIZE && (row + 4) < SIZE && GameManager.Instance.BoardData[col + 4, row + 4] == (int)(oppositeStone)
                        && (col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row - 1);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && (row) == 0 && GameManager.Instance.BoardData[col + 4, row + 4] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 4, row + 4);
                        Debug.Log("* AI put: " + (col + 4) + "행, " + (row + 4) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 4) == SIZE && (row + 4) == SIZE && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row - 1);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }
        // 닫힌 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 11; col++)
        {
            for (int row = 0; row <= 11; row++)
            {
                bool match = true;
                for (int i = 0; i < 4; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 3 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && (row + 4) < SIZE && GameManager.Instance.BoardData[col - 1, row + 4] == (int)(oppositeStone)
                        && (col + 4) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 4, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 4, row - 1);
                        Debug.Log("* AI put: " + (col + 4) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if ((col + 4) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 4, row - 1] == (int)(oppositeStone)
                        && (col - 1) >= 0 && (row + 4) < SIZE && GameManager.Instance.BoardData[col - 1, row + 4] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 4);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 4) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && (row + 4) == SIZE && GameManager.Instance.BoardData[col + 4, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 4, row - 1);
                        Debug.Log("* AI put: " + (col + 4) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 4) == SIZE && (row) == 0 && GameManager.Instance.BoardData[col - 1, row + 4] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 4);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 4) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }


        return false;
    }

    bool IsCloseThree(Stone stone)
    {
        Stone oppositeStone = stone;

        switch (stone)
        {
            case Stone.BLACK_STONE:
                oppositeStone = Stone.WHITE_STONE;
                break;
            case Stone.WHITE_STONE:
                oppositeStone = Stone.BLACK_STONE;
                break;
        }

        // 닫힌 행 3개 체크 (0, 0) (0, 1) (0, 2)
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 12; row++)
            {
                bool match = true;

                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(oppositeStone)
                        && (row + 3) < SIZE && GameManager.Instance.BoardData[col, row + 3] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 3);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 3) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((row + 3) < SIZE && GameManager.Instance.BoardData[col, row + 3] == (int)(oppositeStone)
                        && (row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((row) == 0 && GameManager.Instance.BoardData[col, row + 3] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 3);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 3) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((row + 3) == SIZE && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        // 닫힌 열 3개 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 12; col++)
            {
                bool match = true;

                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row] == (int)(oppositeStone)
                        && (col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(oppositeStone)
                        && (col + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 3, row);
                        Debug.Log("* AI put: " + (col + 3) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && GameManager.Instance.BoardData[col + 3, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 3, row);
                        Debug.Log("* AI put: " + (col + 3) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 3) == SIZE && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }

        }
        // 닫힌 대각선 왼쪽 체크 (나란히 감소하거나 증가하거나)
        for (int col = 0; col <= 12; col++)
        {
            for (int row = 0; row <= 12; row++)
            {
                bool match = true;
                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ((col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(oppositeStone)
                        && (col + 3) < SIZE && (row + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row + 3] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 3, row + 3);
                        Debug.Log("* AI put: " + (col + 3) + "행, " + (row + 3) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;

                    }
                    if ((col + 3) < SIZE && (row + 3) < SIZE && GameManager.Instance.BoardData[col + 3, row + 3] == (int)(oppositeStone)
                        && (col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row - 1);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && (row) == 0 && GameManager.Instance.BoardData[col + 3, row + 3] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 3, row + 3);
                        Debug.Log("* AI put: " + (col + 3) + "행, " + (row + 3) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 3) == SIZE && (row + 3) == SIZE && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row - 1);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }
        // 닫힌 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 12; col++)
        {
            for (int row = 0; row <= 12; row++)
            {
                bool match = true;
                for (int i = 0; i < 3; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 2 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && (row + 3) < SIZE && GameManager.Instance.BoardData[col - 1, row + 3] == (int)(oppositeStone)
                        && (col + 3) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 3, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 3, row - 1);
                        Debug.Log("* AI put: " + (col + 3) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if ((col + 3) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 3, row - 1] == (int)(oppositeStone)
                        && (col - 1) >= 0 && (row + 3) < SIZE && GameManager.Instance.BoardData[col - 1, row + 3] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 3);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 3) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && (row + 3) == SIZE && GameManager.Instance.BoardData[col + 3, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col +3, row - 1);
                        Debug.Log("* AI put: " + (col + 3) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 3) == SIZE && (row) == 0 && GameManager.Instance.BoardData[col - 1, row + 3] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 3);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 3) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        return false;
    }

    bool IsCloseTwo(Stone stone)
    {
        Stone oppositeStone = stone;

        switch (stone)
        {
            case Stone.BLACK_STONE:
                oppositeStone = Stone.WHITE_STONE;
                break;
            case Stone.WHITE_STONE:
                oppositeStone = Stone.BLACK_STONE;
                break;
        }

        // 닫힌 행 2개 체크 (0, 0) (0, 1) (0, 2)
        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;

                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(oppositeStone)
                        && (row + 2) < SIZE && GameManager.Instance.BoardData[col, row + 2] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 2);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((row + 2) < SIZE && GameManager.Instance.BoardData[col, row + 2] == (int)(oppositeStone)
                        && (row - 1) >= 0 && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((row) == 0 && GameManager.Instance.BoardData[col, row + 2] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 2);
                        Debug.Log("* AI put: " + (col) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((row + 2) == SIZE && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("* AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        // 닫힌 열 2개 체크
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col <= 13; col++)
            {
                bool match = true;

                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col + 2) < SIZE && GameManager.Instance.BoardData[col + 2, row] == (int)(oppositeStone)
                        && (col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE) )
                    {
                        GetStonePos(col - 1, row);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                     
                    if ((col - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row] == (int)(oppositeStone)
                        && (col + 2) < SIZE && GameManager.Instance.BoardData[col + 2, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 2, row);
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && GameManager.Instance.BoardData[col+2, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col+2, row);
                        Debug.Log("* AI put: " + (col+2) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 2) == SIZE && GameManager.Instance.BoardData[col-1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col-1, row);
                        Debug.Log("* AI put: " + (col-1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }

        }
        // 대각선 왼쪽 체크 (나란히 감소하거나 증가하거나)
        for (int col = 0; col <= 13; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;
                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    // (0,0) (1,1) (2,2) 기준이 (0,0)
                    if ((col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(oppositeStone)
                        && (col + 2) < SIZE && (row + 2) < SIZE && GameManager.Instance.BoardData[col + 2, row + 2] == (int)(Stone.NONE) )
                    {
                        GetStonePos(col + 2, row + 2);
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;

                    }
                    if ((col + 2) < SIZE && (row + 2) < SIZE && GameManager.Instance.BoardData[col + 2, row + 2] == (int)(oppositeStone)
                        && (col - 1) >= 0 && (row - 1) >= 0 && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE) )
                    {
                        GetStonePos(col - 1, row - 1);
                        Debug.Log("* AI put: " + (col - 2) + "행, " + (row - 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && (row)==0 && GameManager.Instance.BoardData[col + 2, row +2] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 2, row + 2);
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row+2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col + 2) == SIZE && (row + 2) == SIZE && GameManager.Instance.BoardData[col - 1, row-1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row-1);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row-1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }
        // 대각선 오른쪽 체크 (행증가 열감소)
        for (int col = 0; col <= 13; col++)
        {
            for (int row = 0; row <= 13; row++)
            {
                bool match = true;
                for (int i = 0; i < 2; i++)
                {
                    if ((int)stone != GameManager.Instance.BoardData[col + i, row + 1 - i])
                    {
                        match = false;
                    }
                }
                if (match)
                {
                    if ((col - 1) >= 0 && (row + 2) < SIZE && GameManager.Instance.BoardData[col - 1, row + 2] == (int)(oppositeStone)
                        && (col + 2) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 2, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 2, row - 1);
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if ((col + 2) < SIZE && (row - 1) >= 0 && GameManager.Instance.BoardData[col + 2, row - 1] == (int)(oppositeStone)
                        && (col - 1) >= 0 && (row + 2) < SIZE && GameManager.Instance.BoardData[col - 1, row + 2] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 2);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    // 끝부분에서 시작할때, 닿을때 체크.
                    if ((col) == 0 && (row+2) == SIZE && GameManager.Instance.BoardData[col + 2, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + +2, row - 1);
                        Debug.Log("* AI put: " + (col + 2) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    if ((col+2) == SIZE && (row) == 0 && GameManager.Instance.BoardData[col - 1, row + 2] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 2);
                        Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 2) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        return false;
    }

    #endregion

    #region #Method that it check route when stone under three.
    bool IsOne(Stone stone)
    {
        // 상황계산...현재는 랜덤
        int calculateState = Random.Range(1, 3);

        for (int col = 0; col < SIZE; col++)
        {
            for (int row = 0; row < SIZE; row++)
            {
                // 보드데이터에 스톤과 같은 데이터가 있다면
                if ((int)stone == GameManager.Instance.BoardData[col, row]
                    && 0<col && col<14 && 0<row && row<14)
                {

                    // 왼쪽 대각선 열린1, 계산(랜덤)후 위치.
                    if (GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE)
                        && GameManager.Instance.BoardData[col + 1, row + 1] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row - 1);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 1, row + 1);
                                Debug.Log("* AI put: " + (col + 1) + "행, " + (row + 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }

                    // 왼쪽 대각선 닫힌1
                    if (GameManager.Instance.BoardData[col - 1, row - 1] == (int)(GameManager.Instance.oppsiteStone)
                        && GameManager.Instance.BoardData[col + 1, row + 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 1, row + 1);
                        Debug.Log("AI put: " + (col + 1) + "행, " + (row + 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if (GameManager.Instance.BoardData[col + 1, row + 1] == (int)(GameManager.Instance.oppsiteStone)
                        && GameManager.Instance.BoardData[col - 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row - 1);
                        Debug.Log("AI put: " + (col - 1) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 열린 행 1,
                    if (GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE)
                        && GameManager.Instance.BoardData[col, row + 1] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col, row - 1);
                                Debug.Log("AI put: " + col + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col, row + 1);
                                Debug.Log("AI put: " + col + "행, " + (row + 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                        }

                    }

                    // 닫힌 행 1,
                    if (GameManager.Instance.BoardData[col, row - 1] == (int)(GameManager.Instance.oppsiteStone)
                        && GameManager.Instance.BoardData[col, row + 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row + 1);
                        Debug.Log("AI put: " + (col) + "행, " + (row + 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if (GameManager.Instance.BoardData[col, row + 1] == (int)(GameManager.Instance.oppsiteStone)
                    && GameManager.Instance.BoardData[col, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col, row - 1);
                        Debug.Log("AI put: " + (col) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 열린 열1
                    if (GameManager.Instance.BoardData[col - 1, row] == (int)(Stone.NONE)
                        && (GameManager.Instance.BoardData[col + 1, row] == (int)(Stone.NONE)) )
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row);
                                Debug.Log("AI put: " + (col - 1) + "행, " + row + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 1, row);
                                Debug.Log("AI put: " + (col + 1) + "행, " + row + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                        }
                    }

                    // 닫힌 열1
                    if (GameManager.Instance.BoardData[col-1, row] == (int)(GameManager.Instance.oppsiteStone)
                        && GameManager.Instance.BoardData[col+1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col+1, row);
                        Debug.Log("AI put: " + (col+1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if (GameManager.Instance.BoardData[col+1, row] == (int)(GameManager.Instance.oppsiteStone)
                    && GameManager.Instance.BoardData[col-1, row] == (int)(Stone.NONE))
                    {
                        GetStonePos(col-1, row);
                        Debug.Log("AI put: " + (col-1) + "행, " + (row) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }

                    // 오른쪽 대각선 열린1, 계산(랜덤)후 위치.
                    if (GameManager.Instance.BoardData[col - 1, row + 1] == (int)(Stone.NONE)
                        && GameManager.Instance.BoardData[col + 1, row - 1] == (int)(Stone.NONE))
                    {
                        switch (calculateState)
                        {
                            case 1:
                                GetStonePos(col - 1, row + 1);
                                Debug.Log("* AI put: " + (col - 1) + "행, " + (row + 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;
                            case 2:
                                GetStonePos(col + 1, row - 1);
                                Debug.Log("* AI put: " + (col + 1) + "행, " + (row - 1) + "열");
                                GameManager.Instance.PutStone(AInewStonePos);
                                return true;

                        }
                    }

                    // 오른쪽 대각선 닫힌1
                    if (GameManager.Instance.BoardData[col - 1, row + 1] == (int)(GameManager.Instance.oppsiteStone)
                        && GameManager.Instance.BoardData[col + 1, row - 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col + 1, row - 1);
                        Debug.Log("AI put: " + (col + 1) + "행, " + (row - 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                    if (GameManager.Instance.BoardData[col + 1, row - 1] == (int)(GameManager.Instance.oppsiteStone)
                        && GameManager.Instance.BoardData[col - 1, row + 1] == (int)(Stone.NONE))
                    {
                        GetStonePos(col - 1, row + 1);
                        Debug.Log("AI put: " + (col - 1) + "행, " + (row + 1) + "열");
                        GameManager.Instance.PutStone(AInewStonePos);
                        return true;
                    }
                }
            }
        }

        return false;
    }

    bool PutSometing()
    {
        bool isDone = false;
        int col = 0, row = 0;

        // 첫수는 (7,6)
        if (GameManager.Instance.BoardData[7, 6] == (int)(Stone.NONE))
        {
            UIManager.Instance.AIsayUI.text = "첫수는 이곳이 좋겠군...";
            GetStonePos(7, 6);
            Debug.Log("AI put: " + 7 + "행, " + 6 + "열");
            GameManager.Instance.PutStone(AInewStonePos);
            isDone = true;
            return true;
        }
        // 빈곳 찾을때까지 랜덤
        while (!isDone)
        {
            col = Random.Range(0, 14);
            row = Random.Range(0, 14);
            GetStonePos(col, row);

            if (GameManager.Instance.BoardData[col, row] == (int)(Stone.NONE))
            {
                UIManager.Instance.AIsayUI.text = "마땅한 수가 생각나지 않는군 !";
                Debug.Log("AI put: " + col + "행, " + row + "열");
                GameManager.Instance.PutStone(AInewStonePos);
                isDone = true;
                return true;
            }
        }

        return false;

    }
    #endregion


}
