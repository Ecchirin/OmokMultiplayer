﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput : MonoBehaviour {

    GameObject newStonePos=null;

    private void Update()
    {
        if (GameManager.Instance.isPlaying)
        {
            if (Input.GetMouseButtonDown(0))
            {
                // 새로운 좌표값으로 "Board" 태그가 있는 위치를 받아온다.
                newStonePos = GetBoardPositon();
            }
            // null 레퍼런스 오류 보기 싫어서
            if (newStonePos==null || newStonePos.tag != "Board")
            {
                return;
            }

            // 플레이어턴이고, 태그가 Board일때...
            if(GameManager.Instance.currentTurn==Turn.PLAYER_TURN 
                && Input.GetMouseButtonUp(0) 
                && newStonePos.tag=="Board"
                && GameManager.Instance.isPlaying)
            {
                GameManager.Instance.PutStone(newStonePos);
            }
        }
    }

    // 태그를 이용하여 보드 오브젝트인지 체크 후 좌표값을 받아온다...
    private GameObject GetBoardPositon()
    {
        RaycastHit hit;
        GameObject target = null;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray.origin, ray.direction, out hit))
        {
            target = hit.collider.gameObject;
            if (target.gameObject.tag == "Board") return target;
        }
        return target;
    }
}
