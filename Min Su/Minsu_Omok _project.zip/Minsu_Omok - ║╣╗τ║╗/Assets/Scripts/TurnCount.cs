﻿using UnityEngine;
using UnityEngine.UI;

public class TurnCount : MonoBehaviour {

    private Text myText;
    private static int NUMBER=1;
    private bool resetOK = false;

    private void Awake()
    {
        resetOK = false;

        myText = GetComponentInChildren<Canvas>().GetComponentInChildren<Text>();
        myText.text = "" + NUMBER;
        NUMBER++;
    }

    private void Update()
    {
        if (GameManager.Instance.isPlaying && resetOK)
        {
            resetOK = false;
        }

        if (!GameManager.Instance.isPlaying && !resetOK)
        {
            NUMBER = 1;
            resetOK = true;
        }
    }

}
