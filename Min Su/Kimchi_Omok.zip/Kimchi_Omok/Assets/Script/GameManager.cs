﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// 배열 기본값이 0이라 NONE을 이용함.
public enum Stone { NONE, BLACK_STONE, WHITE_STONE }
public enum Turn { PLAYER_TURN, AI_TURN }

public class GameManager : MonoBehaviour {
    // 싱글톤
    private static GameManager instance = null;
    public static GameManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<GameManager>();
                // 그래도 없다면
                if(instance==null)
                {
                    GameObject container = new GameObject("GameManager");
                    instance = container.AddComponent<GameManager>();
                }
            }
            return instance;
        }
    }

    public Stone currentStone;
    public Turn currentTurn;

    // 오목데이터 저장용 2차원 배열
    private static byte SIZE = 15;
    public int[,] BoardData = new int[SIZE, SIZE];

    //프리팹들 ( 흑돌,백돌, 홀더 )
    public GameObject BlackStone;
    public GameObject WhiteStone;
    public GameObject StoneHolder;

    // 게임 플레이, 종료 체크
    public bool isPlaying = true;

    // 임시 UI관련
    public Text stateUI;
    public int turnCount = 1;

    private void Awake()
    {
        currentStone= Stone.BLACK_STONE;
        currentTurn = Turn.PLAYER_TURN;
    }

    // 위치를 받아, 스톤 인스턴스를 생성
    public void PutStone(GameObject obj)
    {
        // 행, 열
        int column = 0, row = 0;

        // obj의 이름과 부모이름을 이용해서 좌표값을 저장한다.
        string objName = obj.name;
        string objParentName = obj.transform.parent.name;

        column = System.Convert.ToInt32(objName);
        row= System.Convert.ToInt32(objParentName);

        // BoardData와 위치가 중첩되지 않을때, 즉 0일때
        if (BoardData[row, column] == (int)(Stone.NONE) )
        {
            // 위치 기록
            BoardData[row, column] = (int)(currentStone);

            switch (currentStone)
            {
                case Stone.BLACK_STONE:
                    Instantiate(BlackStone, obj.transform.position, Quaternion.identity, StoneHolder.transform);
                    currentStone = Stone.WHITE_STONE;
                    break;
                case Stone.WHITE_STONE:
                    Instantiate(WhiteStone, obj.transform.position, Quaternion.identity, StoneHolder.transform);
                    currentStone = Stone.BLACK_STONE;
                    break;
            }

            switch (currentTurn)
            {
                case Turn.PLAYER_TURN:
                    currentTurn = Turn.AI_TURN;
                    break;
                case Turn.AI_TURN:
                    currentTurn = Turn.PLAYER_TURN;
                    turnCount++;
                    break;
            }

            // UI 업데이트
            UpdateUI();
        }
        else
        {
            Debug.Log("중복된 위치 입니다...!");
        }
    }

    private void UpdateUI()
    {
        stateUI.text = "Turn : " + turnCount;   
    }

    bool IsWin()
    {
        // 승리체크 구현
        return false;
    }
}
