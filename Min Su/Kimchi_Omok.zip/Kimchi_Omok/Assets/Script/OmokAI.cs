﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OmokAI : MonoBehaviour
{
    // 오브젝트 받아옴.
    private GameObject AInewStonePos;

    private void Update()
    {
        if (GameManager.Instance.isPlaying)
        {
            if (GameManager.Instance.currentTurn == Turn.AI_TURN)
            {
                AIPut();
            }
        }

    }
    // 오버라이드 할 예정
    public virtual void AIPut()
    {
        int row = 0, column = 0;

        row = Random.Range(0, 14);
        column = Random.Range(0, 14);

        GetStonePos(row, column);

        if (GameManager.Instance.BoardData[row, column] == (int)(Stone.NONE) )
        {
            Debug.Log("AI put: " + row + ", " + column);

            GameManager.Instance.PutStone(AInewStonePos);
        }
        else
        {
            Debug.Log("이것이 나온다면 AI가 씹혔다는것이다.");
        }

    }

    //매니저에게 돌의 위치를 전달하는 함수
    public void GetStonePos(int y, int x)
    {
        GameObject board = GameObject.Find("Board");
        Transform[] boardChild1 = new Transform[board.transform.childCount];
        for (int i = 0; i < board.transform.childCount; i++)
            boardChild1[i] = board.transform.GetChild(i);

        Transform[] boardChild2 = new Transform[boardChild1[y].childCount];
        for (int i = 0; i < boardChild1[y].childCount; i++)
            boardChild2[i] = boardChild1[y].transform.GetChild(i);

        AInewStonePos = boardChild2[x].gameObject;
    }

}
